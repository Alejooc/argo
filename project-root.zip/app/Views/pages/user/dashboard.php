<section class="px-4 text-white slota shadow-sm mb-0">
        <div class="d-flex">
            <div class="d-none d-md-block hotelcont flex-fill">
                <img src="<?=base_url()?>/assets/img/hotel.png" alt="" class="hotel">
            </div>
            <div class="desclang text-center py-3">
                <img  class="img-fluid" src="<?=base_url()?>/assets/img/icons/logo.gif" alt="">
                <h2 class="mb-3">¿?</h2>
                <p class="text-landing d-none d-sm-block">Bienvenido a Habbo, un hotel virtual en el que puedes conocer a gente de tu edad, crear y decorar tus propias salas, e incluso cuidar de tus mascotas o… comprar créditos y raros en el catálogo de manera gratuita, porque recuerda, ¡Habbo es gratis!</p>
                <div class="registerbox">
                    <a type="button" href="<?=base_url()?>/register" class="btn btn-lg btnreg shadow-sm">!JUGAR AHORA¡</a>
                    <a type="button" data-bs-toggle="modal" data-bs-target="#login" href="<?=base_url()?>/register" class="btn btn-lg btnlogin shadow-sm">!DESCARGAR APP¡</a>
                    <img src="<?=base_url()?>/assets/img/icons/finger_push.gif" class="img-fluid hand d-none d-md-block" alt=""> 
                </div>

            </div>
        </div>
</section>
<section class="px-4 bg-light shadow-sm py-2 mb-4">
    <nav class="navbar navbar-expand-sm navbar-light h-25">
        <div class="container-fluid ">
            <a class="navbar-brand" href="javascript:void(0)">Logo</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mynavbar">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                    <a class="nav-link" href="javascript:void(0)">Home</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="javascript:void(0)">Comunidad</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="javascript:void(0)">Link</a>
                    </li>
                </ul>

                <div class="d-flex h-25">
                    <div class="avatar" style="height: 50px; overflow:hidden;position:relative">
                        <img src="https://www.habbo.com.br/habbo-imaging/avatarimage?figure=lg-275-110.ch-262-110.ea-6136543-110.hr-893-61.hd-206-1.sh-295-64&action=none,crr=1&direction=2&head_direction=2&gesture=sml&size=l" alt="" srcset="">
                    </div>
                
                    <span  class="bg-secondary rounded p-2">
                        <img src="https://3.bp.blogspot.com/-rtbdjpCS9S4/Xz2Pz03vb-I/AAAAAAABdL4/JP7ceNRAgzclJoYV8hb6amq9q2VKXRD0ACPcBGAsYHg/s1600/moedas1.png" alt="" class="img-fluid">
                        5000
                    </span>
                    <span  class="bg-secondary rounded p-2">
                        <img src="https://1.bp.blogspot.com/-sPGhJarAYSg/Xz2Pzy90_6I/AAAAAAABdL4/8kXYGKUgG1IJ3S9C8_JlbzVG-RcarxopACPcBGAsYHg/s1600/Duckets.png" alt="">
                        5000
                    </span>
                    <span  class="bg-secondary rounded p-2">
                        <img src="https://4.bp.blogspot.com/-cOt3E-iXaGU/Xz2PzwXLjSI/AAAAAAABdL4/FHM2sIJewmE3UuajMUFyijCamSzeQSiEgCPcBGAsYHg/s1600/Diamantes.png" alt="" class="img-fluid">
                        5000
                    </span>     
                </div>
            </div>
        </div>
    </nav>
</section>
<section class="px-4 text-dark slotc mb-0">
    <div class="row">
        <!--izquierda!-->
        <div class="col-12 col-md-8">
            <div class="card " style="background-color: unset;">
                <h4 class="text-dark">NOTICIAS</h4> 
                <div class="col-12 noticedest">
                    <div class="text-notice">
                        <h4>CONSEJOS DE SEGURIDAD</h4> 
                        <span >
                        2 nov. 2021 |
                            <a href="" class="categorynew">Campañas y Actividades</a>
                        </span>
                        <p class="pt-3">¡Tenemos nuevas recetas Bubblejuice, así como ingredientes y furnis con los que disfrutar de una experiencia superbubble!</p>
                    </div>
                    <img src="https://images.habbo.com/web_images/habbo-web-articles/lpromo_nov21.png" alt="Los Angeles" class="d-block shadow noticeimg">
                </div>
            </div>
            <div class="card">
                
                a
            </div>
        </div>
        <!--Derecha!-->
        <div class="col-12 col-md-4">
            <div class="card p-2">
                <h5>Ultimos Eventos</h5> 
                <div class="card-body">
                    a
                </div>
            </div>
            <div class="card">
                <h5>Ultimos Eventos</h5> 
                <div class="card-body">
                    a
                </div>
            </div>
        </div> 
    </div>
    
</section>


